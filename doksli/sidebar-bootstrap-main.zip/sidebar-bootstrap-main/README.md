# Create Responsive Sidebar Menu | Sidebar Bootstrap 5

Create a straightforward sidebar with Bootstrap 5 that features a nested dropdown link. This design is mobile-friendly, easy to code, and can be scaled effortlessly for different projects.

[![youtube](https://img.shields.io/badge/YouTube-red?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@codzsword)

![Logo](https://raw.githubusercontent.com/codzsword/sidebar-bootstrap/main/Sidebar-With-Bootstrap-Demo.png)
